﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _5T23_MassartNathan_BlackJack
{
    class Class1
    {
    }
}
