﻿using System;

namespace _5T23_MassartNathan_BlackJack
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
