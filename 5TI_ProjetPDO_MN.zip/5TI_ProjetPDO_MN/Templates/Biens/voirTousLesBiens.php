

   
<div class = "photo space-around ">
    <h1>Game Center</h1> 
    <img src="Images/logo_game_center.png" alt="image" style=" width: 250px">
</div>
<div class="flex wrap space-around">
    <div class="border card">
        <h2 class="center">Minecraft</h2>
        <div>
            <div class="flex blocImageBien"><img src="https://i.guim.co.uk/img/media/051e1e1d1fb94f7e4a591394a460e8a8ac865a3c/160_31_1706_1024/master/1706.jpg?width=620&quality=85&dpr=1&s=none" alt="image lorem picsum" /></div>
            <div class="center">
                <p><span></span> - <span></span></p>
                <h3></h3>
                <a href="/voirLeBien" class="btn btn-page">Voir les disponibilités</a>
            </div>
        </div>
    </div>
    <div class="border card">
        <h2 class="center">Grand Theft Auto 5</h2>
        <div>
            <div class="flex blocImageBien"><img src="https://lesitetech.fr/wp-content/uploads/2019/08/gta-5-configuration-pc-requise.jpg" alt="image lorem picsum" /></div>
            <div class="center">
                <p><span></span> - <span></span></p>
                    <h3></h3>
                <a href="/voirLeBien" class="btn btn-page">Voir les disponibilités</a>
            </div>
        </div>
    </div>
    <div class="border card">
        <h2 class="center"> Black ops II</h2>
        <div>
            <div class="flex blocImageBien"><img src="https://gamecomputers.nl/blog/wp-content/uploads/2012/10/call_of_duty_black_ops_2wide-1024x640.jpg" alt="image lorem picsum" /></div>
            <div class="center">
                <p><span></span> - <span></span></p>
                    <h3></h3>
                <a href="/voirLeBien" class="btn btn-page">Voir les disponibilités</a>
            </div>
        </div>
    </div>
    <div class="border card">
        <h2 class="center">Overwatch</h2>
        <div>
            <div class="flex blocImageBien"><img src="https://lesitetech.fr/wp-content/uploads/2019/08/overwatch-configuration-pc-requise.jpg" alt="image lorem picsum" /></div>
            <div class="center">
            <p><span></span> - <span></span></p>
                <h3></h3>
                <a href="/voirLeBien" class="btn btn-page">Voir les disponibilités</a>
            </div>
        </div>
    </div>
    <div class="border card">
        <h2 class="center">Overwatch</h2>
        <div>
            <div class="flex blocImageBien"><img src="https://lesitetech.fr/wp-content/uploads/2019/08/overwatch-configuration-pc-requise.jpg" alt="image lorem picsum" /></div>
            <div class="center">
            <p><span></span> - <span></span></p>
                <h3></h3>
                <a href="/voirLeBien" class="btn btn-page">Voir les disponibilités</a>
            </div>
        </div>
    </div>
    <div class="border card">
        <h2 class="center">Overwatch</h2>
        <div>
            <div class="flex blocImageBien"><img src="https://lesitetech.fr/wp-content/uploads/2019/08/overwatch-configuration-pc-requise.jpg" alt="image lorem picsum" /></div>
            <div class="center">
            <p><span></span> - <span></span></p>
                <h3></h3>
                <a href="/voirLeBien" class="btn btn-page">Voir les disponibilités</a>
            </div>
        </div>
    </div>
    <div class="border card">
        <h2 class="center">Overwatch</h2>
        <div>
            <div class="flex blocImageBien"><img src="https://lesitetech.fr/wp-content/uploads/2019/08/overwatch-configuration-pc-requise.jpg" alt="image lorem picsum" /></div>
            <div class="center">
            <p><span></span> - <span></span></p>
                <h3></h3>
                <a href="/voirLeBien" class="btn btn-page">Voir les disponibilités</a>
            </div>
        </div>
    </div>
    <div class="border card">
        <h2 class="center">Overwatch</h2>
        <div>
            <div class="flex blocImageBien"><img src="https://lesitetech.fr/wp-content/uploads/2019/08/overwatch-configuration-pc-requise.jpg" alt="image lorem picsum" /></div>
            <div class="center">
            <p><span></span> - <span></span></p>
                <h3></h3>
                <a href="/voirLeBien" class="btn btn-page">Voir les disponibilités</a>
            </div>
        </div>
    </div>
    <div class="border card">
        <h2 class="center">Overwatch</h2>
        <div>
            <div class="flex blocImageBien"><img src="https://lesitetech.fr/wp-content/uploads/2019/08/overwatch-configuration-pc-requise.jpg" alt="image lorem picsum" /></div>
            <div class="center">
            <p><span></span> - <span></span></p>
                <h3></h3>
                <a href="/voirLeBien" class="btn btn-page">Voir les disponibilités</a>
            </div>
        </div>
    </div>
    <div class="border card">
        <h2 class="center">Overwatch</h2>
        <div>
            <div class="flex blocImageBien"><img src="https://lesitetech.fr/wp-content/uploads/2019/08/overwatch-configuration-pc-requise.jpg" alt="image lorem picsum" /></div>
            <div class="center">
            <p><span></span> - <span></span></p>
                <h3></h3>
                <a href="/voirLeBien" class="btn btn-page">Voir les disponibilités</a>
            </div>
        </div>
    </div>
</div>
