
<h1>Votre page profil</h1>
<ol>
    <div>
        <li>Nom</li>
        <p>de Mahieu</p>
    </div>
    <div>
        <li>Prénom</li>
        <p>Benoit</p>
    </div>
    <div>
        <li>Adresse postale</li>
        <p>Place de la route, 5151 Anvers</p>
    </div>
    <div>
        <li>Photo de profil</li>
        <div class="progress">
            <div class="progress-bar"></div>
        </div>
        <img id="imageProfil" src="Images/profil.png" alt="Mon image de profil">
    </div>
</ol>