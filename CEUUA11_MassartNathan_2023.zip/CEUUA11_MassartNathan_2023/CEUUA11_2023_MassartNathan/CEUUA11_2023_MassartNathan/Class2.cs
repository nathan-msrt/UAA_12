﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CEUUA11_2023_MassartNathan
{
    class Class2
    {
    }
}
